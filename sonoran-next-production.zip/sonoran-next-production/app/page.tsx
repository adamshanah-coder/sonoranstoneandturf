import Image from 'next/image';
import { Camera, Gem, MapPin, ShieldCheck, Sparkles, Star, Upload, Wand2 } from 'lucide-react';

const services = [
  ['Artificial Turf', 'Premium, pet-friendly turf that stays green year-round.'],
  ['Decorative Gravel', 'Clean, low-maintenance rock and gravel built for Arizona.'],
  ['Pavers & Hardscapes', 'Patios, walkways, borders, fire features, and entertaining spaces.'],
  ['Putting Greens', 'Custom backyard putting greens for daily use and visual impact.'],
  ['Complete Transformations', 'Full outdoor redesigns that bring turf, stone, and living spaces together.'],
];

const cities = ['Phoenix','Scottsdale','Paradise Valley','Gilbert','Chandler','Mesa','Tempe','Peoria','Glendale','Surprise','Goodyear','Queen Creek'];

export default function Home() {
  return (
    <main>
      <header className="nav">
        <a className="brand" href="#top">
          <Image src="/logo.jpeg" alt="Sonoran Turf & Gravel logo" width={72} height={72} priority />
          <span>Sonoran Turf & Gravel</span>
        </a>
        <nav>
          <a href="#services">Services</a>
          <a href="#vision">Sonoran Vision™</a>
          <a href="#gallery">Gallery</a>
          <a href="#areas">Areas</a>
          <a href="#contact" className="pill">Free Estimate</a>
        </nav>
      </header>

      <section id="top" className="hero">
        <div className="heroShade" />
        <div className="heroContent">
          <p className="eyebrow">Licensed & Insured • Greater Phoenix Area</p>
          <h1>Transform Your Outdoor Living</h1>
          <p className="lead">Premium turf, decorative gravel, pavers, putting greens, and complete landscape transformations designed for Arizona beauty and built to last.</p>
          <div className="actions">
            <a href="#contact" className="button gold">Get a Free Estimate</a>
            <a href="#vision" className="button glass"><Sparkles size={18}/> Reimagine My Yard™</a>
          </div>
          <p className="serve"><MapPin size={18}/> Proudly serving the Greater Phoenix Area</p>
        </div>
      </section>

      <section className="trust">
        <div><ShieldCheck/><strong>Licensed & Insured</strong><span>Professional, reliable, and protected.</span></div>
        <div><Wand2/><strong>Desert Experts</strong><span>Landscapes designed for Arizona’s climate.</span></div>
        <div><Gem/><strong>Premium Materials</strong><span>High-quality products built to last.</span></div>
        <div><Star/><strong>Quality Craftsmanship</strong><span>Clean, detailed installations every time.</span></div>
      </section>

      <section id="services" className="section services">
        <p className="eyebrow center">Complete Outdoor Solutions</p>
        <h2>Everything Your Yard Deserves</h2>
        <p className="intro">From design to installation, we create beautiful, functional outdoor spaces tailored to your lifestyle and built for Arizona living.</p>
        <div className="serviceGrid">
          {services.map((s, i) => <article key={s[0]}><div className={`serviceImage img${i}`} /><h3>{s[0]}</h3><p>{s[1]}</p><a href="#contact">Learn more →</a></article>)}
        </div>
      </section>

      <section id="vision" className="vision">
        <div>
          <p className="eyebrow">Experience the Possibilities</p>
          <h2>Sonoran Vision™</h2>
          <p>Upload a photo of your yard and receive premium design directions inspired by modern Arizona outdoor living. Built to capture qualified leads from homeowners who want more than a basic estimate.</p>
          <div className="steps">
            <span><Upload/>Upload a photo</span>
            <span><Camera/>Choose your style</span>
            <span><Sparkles/>Receive concepts</span>
            <span><MapPin/>Schedule consult</span>
          </div>
          <a className="button gold" href="#contact">Start Designing Now</a>
        </div>
        <div className="visionPanel">
          <div className="upload">Upload Yard Photo</div>
          <div className="conceptCards"><div>Modern Desert</div><div>Luxury Resort</div><div>Family Backyard</div></div>
        </div>
      </section>

      <section id="gallery" className="section gallery">
        <p className="eyebrow center">Concept Renderings</p>
        <h2>Before & After</h2>
        <p className="intro">Launch-ready visual direction. Replace concept visuals with real project photography as your portfolio grows.</p>
        <div className="compare"><div><span>Before</span></div><div><span>After</span></div></div>
      </section>

      <section className="why">
        <div>
          <p className="eyebrow">Why Choose Us</p>
          <h2>We Don’t Just Install. We Transform.</h2>
          <p>We focus on thoughtful design, quality materials, and clean installation to create outdoor spaces that add value, beauty, and enjoyment for years to come.</p>
        </div>
        <ul><li>Custom designs for every property</li><li>Low-maintenance, high-impact solutions</li><li>Professional service from start to finish</li><li>Licensed & insured for peace of mind</li></ul>
      </section>

      <section id="areas" className="areas">
        <p className="eyebrow center">Service Area</p>
        <h2>Proudly Serving Greater Phoenix</h2>
        <p>{cities.join(' • ')}</p>
      </section>

      <section id="contact" className="contact">
        <div>
          <p className="eyebrow">Let’s Build Your Dream Yard</p>
          <h2>Request your free consultation.</h2>
          <p>Tell us about your project and we’ll follow up to discuss your goals, style, budget, and timeline.</p>
          <a href="tel:+14809150477" className="contactLink">+1 (480) 915-0477</a>
          <a href="mailto:info@sonoranturfandgravel.com" className="contactLink">info@sonoranturfandgravel.com</a>
        </div>
        <form action="mailto:info@sonoranturfandgravel.com" method="post" encType="text/plain">
          <input name="name" placeholder="Name" required />
          <input name="phone" placeholder="Phone" required />
          <input name="email" placeholder="Email" type="email" />
          <input name="city" placeholder="City" />
          <select name="project"><option>Complete Landscape Transformation</option><option>Artificial Turf</option><option>Decorative Gravel</option><option>Pavers & Hardscapes</option><option>Putting Green</option><option>Sonoran Vision™ Concept</option></select>
          <select name="budget"><option>Budget range</option><option>$5k–$10k</option><option>$10k–$25k</option><option>$25k+</option></select>
          <textarea name="details" placeholder="Tell us about your yard" rows={5} />
          <button className="button gold" type="submit">Send Request</button>
        </form>
      </section>

      <footer><Image src="/logo.jpeg" alt="Sonoran Turf & Gravel logo" width={120} height={120}/><p>Premium landscape transformations built for Arizona living.</p><p>+1 (480) 915-0477<br/>info@sonoranturfandgravel.com</p></footer>
    </main>
  );
}
