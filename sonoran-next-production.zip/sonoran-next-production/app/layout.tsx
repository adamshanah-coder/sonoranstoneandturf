import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Sonoran Turf & Gravel | Premium Landscape Transformations',
  description: 'Premium turf, gravel, pavers, putting greens, and landscape transformations across the Greater Phoenix area.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
